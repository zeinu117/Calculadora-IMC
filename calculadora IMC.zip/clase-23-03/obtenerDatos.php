<?php

    
    $valor1 = $_POST["v1"];
    $valor2 = $_POST["v2"];
    $resultado = 0;
    $opcion = $_POST["opcion"];

    switch($opcion){
        case "sumar":
            $resultado = $valor1 + $valor2;
            break;
        case "restar":
            $resultado = $valor1 - $valor2;
            break;
        case "multiplicar":
            $resultado = $valor1 * $valor2;
            break;
        case "dividir":
            $resultado = $valor1 / $valor2;
            break;
    }

    echo $resultado;

    echo "<br>";

?>
<a href="index.php">regresar</a>